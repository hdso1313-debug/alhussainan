/* مستخرج حرفياً من التصميم الأصلي: السلايدر + الإشعارات (السلة والمنتجات تأتي من سلة) */
const $=s=>document.querySelector(s);
/* ===== إعدادات الإشعارات (قابلة للتغيير): عنوان + نص ===== */
const NOTICES=[
 ["هدية الضيافة","احصل على علبة مجانية مع كل صندوق هدايا"],
 ["شحن مجاني","للطلبات فوق ٣٠٠ ر.س إلى جميع المناطق"],
 ["حصاد هذا الموسم","سكري القصيم وصل طازجاً اليوم"],
 ["تغليف نجدي","نقوش تراثية على علب الإهداء"]];

if(window.HS_NOTICES)NOTICES.splice(0,NOTICES.length,...window.HS_NOTICES);
if(document.querySelector('.slide')){
/* السلايدر */
const sl=[...document.querySelectorAll(".slide")];let cur=0,tm;
sl.forEach(s=>{const im=s.querySelector("img.bg");if(im&&!im.getAttribute("src"))im.remove()});
$("#dots").innerHTML=sl.map((_,i)=>`<button onclick="go(${i})" aria-label="شريحة ${i+1}"></button>`).join("");
function go(i){cur=(i+sl.length)%sl.length;sl.forEach((s,j)=>s.classList.toggle("on",j==cur));[...$("#dots").children].forEach((d,j)=>d.classList.toggle("on",j==cur));clearInterval(tm);tm=setInterval(()=>go(cur+1),5500)}
$("#nx").onclick=()=>go(cur+1);$("#pv").onclick=()=>go(cur-1);go(0);
/* الإشعارات */
let ni=0;const T=$("#toast");
function note(){const[a,b]=NOTICES[ni++%NOTICES.length];$("#tt").textContent=a;$("#tb").textContent=b;T.classList.add("on");setTimeout(()=>T.classList.remove("on"),5000)}
$("#tx").onclick=()=>T.classList.remove("on");
setTimeout(()=>{note();setInterval(note,12000)},3000);

}
